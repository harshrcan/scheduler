# Dayframe — Personal Time Planner

Clean planner with week/month/day views, colored task cards, Notion-style checklist,
and real-time sync across all devices via Supabase.

---

## Quick Start (local)

npm install
npm run dev

Open http://localhost:5173 — works immediately in local-only mode.

---

## Project Structure

src/
  lib/supabase.js          Supabase client (reads .env)
  hooks/useTasks.js        All task logic: localStorage + Supabase sync
  components/
    TaskCard.jsx           Colored task boxes + AddTaskForm
    WeekView.jsx           7-column week grid
    MonthView.jsx          Month calendar with dot indicators
    DayView.jsx            Single-day view with focus note
    ChecklistPanel.jsx     Right-side Notion-style checklist
  utils/dates.js           Date helpers
  App.jsx                  Root layout + top bar + view routing
  index.css                CSS variables, light/dark mode
supabase/schema.sql        Run once in Supabase SQL Editor
.env.example               Copy to .env and fill in your keys
vercel.json                Vercel SPA routing fix

---

## STEP 1 — Set up Supabase (for sync)

1. Go to https://supabase.com → sign up (free)
2. Click "New project" → name it "dayframe" → pick a region (US West for Vancouver)
3. Wait ~2 min for it to provision
4. Go to SQL Editor (left sidebar) → New query
5. Paste the entire contents of supabase/schema.sql → click Run
6. Go to Project Settings → API
7. Copy:
   - Project URL  (like https://abcdefgh.supabase.co)
   - anon / public key (long string under "Project API keys")

---

## STEP 2 — Configure .env

Open .env and replace the placeholders:

  VITE_SUPABASE_URL=https://abcdefgh.supabase.co
  VITE_SUPABASE_ANON_KEY=eyJhbGci...

Save, restart dev server (Ctrl+C then npm run dev).
You should see green "synced" in the top bar.

---

## STEP 3 — Deploy to Vercel

1. Install Git: https://git-scm.com
2. Create a GitHub account: https://github.com
3. Create a new repo on GitHub (call it "dayframe", set to Private)
4. In your terminal inside the project folder:

   git init
   git add .
   git commit -m "initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/dayframe.git
   git push -u origin main

5. Go to https://vercel.com → sign up with GitHub
6. Click "Add New Project" → import your dayframe repo
7. Before deploying, click "Environment Variables" and add:
   - VITE_SUPABASE_URL
   - VITE_SUPABASE_ANON_KEY
8. Click Deploy (~30 seconds)
9. You get a live URL like dayframe-harsh.vercel.app

After every change just run: git add . && git commit -m "msg" && git push
Vercel auto-deploys every push.

---

## STEP 4 — Use on phone

Open your Vercel URL on your phone browser.
Add to home screen:
  iPhone:  Safari → Share → Add to Home Screen
  Android: Chrome → three-dot menu → Add to Home Screen

Real-time sync: add a task on phone → appears on desktop instantly (and vice versa).

---

## How sync works

  Phone                Desktop
    |                     |
    | add task            |
    v                     |
 localStorage             |
 (instant)                |
    |                     |
    v                     |
  Supabase  ──────────►  realtime subscription fires
  (cloud DB)              → state updates instantly

Tasks saved to localStorage immediately (fast UI), then written to Supabase.
All open instances get updates via WebSocket.

---

## Task colors

Pick a color when adding a task. Tags auto-assign colors but you can override.

  Tag       Default color
  work      blue
  personal  purple
  urgent    coral
  health    green

Available colors: purple, blue, teal, coral, amber, pink, green

---

## Tech Stack

  React + Vite       Frontend, fast dev server
  Supabase (Postgres) Free hosted DB, real-time WebSockets
  Vercel             Auto-deploy from GitHub, free tier
  localStorage       Instant UI + offline cache
